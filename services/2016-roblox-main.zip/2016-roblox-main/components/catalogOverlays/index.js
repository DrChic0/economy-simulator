const CatalogOverlays = props => {
  return <div>

  </div>
}

export default CatalogOverlays;