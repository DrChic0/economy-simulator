namespace Roblox.Models.Users;

public enum WebsiteYear
{
    Year2016 = 1,
    Year2021 = 2,
}