using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Roblox.Website.Pages.Auth;

public class Discord : RobloxPageModel
{
    public void OnGet()
    {
        
    }
}