using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Roblox.Website.Pages.Auth;

public class TOS : RobloxPageModel
{
    public void OnGet()
    {
        
    }
}