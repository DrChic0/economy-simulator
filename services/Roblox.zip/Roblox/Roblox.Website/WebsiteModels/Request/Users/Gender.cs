namespace Roblox.Models.Users;

public class UpdateGenderRequest
{
    public Gender gender { get; set; }
}