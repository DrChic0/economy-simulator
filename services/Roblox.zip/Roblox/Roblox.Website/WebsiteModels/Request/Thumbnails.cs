namespace Roblox.Website.WebsiteModels.Thumbnails;

public class BatchRequestEntry
{
    public string requestId { get; set; }
    public string type { get; set; }
    public long targetId { get; set; }
}