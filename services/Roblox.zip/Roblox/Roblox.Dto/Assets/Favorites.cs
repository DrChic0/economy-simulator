namespace Roblox.Dto.Assets;

public class FavoriteEntry
{
    public long userId { get; set; }
    public long assetId { get; set; }
    public DateTime created { get; set; }
}